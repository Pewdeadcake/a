export J2SDKDIR=/usr/lib/jvm/java-17-oracle
export J2REDIR=/usr/lib/jvm/java-17-oracle
export PATH=$PATH:/usr/lib/jvm/java-17-oracle/bin:/usr/lib/jvm/java-17-oracle/db/bin
export JAVA_HOME=/usr/lib/jvm/java-17-oracle
export DERBY_HOME=/usr/lib/jvm/java-17-oracle/db
